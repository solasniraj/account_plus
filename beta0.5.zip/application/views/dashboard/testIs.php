


<p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;">
    <b>

<span style="color: rgb(0, 32, 96); font-family: 'Calibri','sans-serif';">
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2">Administrative and Support Staff</font>
        
</span></b>
</p>


<p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;">&nbsp;</p>


<p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;">
    <font face="Calibri, Verdana, Times New Roman" size="2">
    

<span style="font-family: Calibri,Verdana,Times New Roman;">The administrative and financial management unit is headed by an&nbsp;Executive Officer (Masters in Business Administration) who has a significant experience in both administrative as well as&nbsp;financial management. He is supported by an Accounts Officer and a Logistics Assistant and several support staff. 
</span>
<br></font></p>  

<p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;">
<br></p>


<p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;">&nbsp;</p>

<table style="width: 642px; font-family: Verdana,Arial,Helvetica,sans-serif; height: 283px;" border="0" cellpadding="4" cellspacing="0"> 
    <tbody>  
        
<tr>
</tr> 
        
<tr>
            
<td style="text-align: justify;">
                <font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Krishna Ji Ghimire</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
                <img style="width: 99px; height: 121px;" alt="" src="http://www.isernepal.org.np/admin/pg/PG_a85e0dfd50d74fa1fb16379bfd80a0c0.jpeg" align="right" border="0"></font>
                <font size="1"><br style="font-family: Calibri,Verdana,Times New Roman;"></font>
                <font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Executive Officer</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br>
                </font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">MBA&nbsp; </font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Tribhuvan University, Nepal</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br><a href="mailto:%20kghimire@isernepal.org.np" target="_blank">E-mail </a></font><font size="2">
<br></font><font size="2">
<br>
<br>
<br></font>
</td>  
<td style="text-align: justify;">
<br>
</td>  
<td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Mangal Raj DaraiMangal</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
    <img style="width: 90px; height: 117px;" alt="MAngal Raj Darai" src="http://www.isernepal.org.np/admin/pg/PG_cd4c83df82671cd221806d5b1e003d71.jpeg" align="right" border="0">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Assistant Account Officer</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">I.A./I.Com. </font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Tribhuvan University, Nepal</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br></font><font size="2">
<br>
<br>
<br></font>
</td>
</tr>  
<tr>  
<td style="text-align: justify;"><font size="2"><img style="width: 100px; height: 123px;" alt="Bamdev Adhikari" src="http://www.isernepal.org.np/admin/pg/PG_9f94fd3cf602796763cf59d164a30c28.jpeg" align="right" border="0"></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Bamdev Adhikari</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Logistic Assistant</font><font size="2">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">
<br></font>
</td>  
<td style="text-align: justify;"><font size="2">&nbsp;</font>
</td>  
<td style="text-align: justify;"><font size="2"><img style="width: 90px; height: 112px;" alt="Rishi Neupane" src="http://www.isernepal.org.np/admin/pg/PG_6e8d1e700318e528b3de3c956e2a43af.jpeg" align="right" border="0"></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Rishi Neupane</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><font size="1">

<span style="font-family: Calibri,Verdana,Times New Roman;">Senior Office Assistant
</span></font>
<br>
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">
<br></font>
</td>
</tr>  
<tr>  
<td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">
<br></font><font size="2"><img style="width: 90px; height: 104px;" alt="Bimal Darai" src="http://www.isernepal.org.np/admin/pg/PG_7c0b8109f24643864fd67ff7e95f9bab.jpeg" align="right" border="0"></font>
<br><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Bimal Darai</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><font size="1">

<span style="font-family: Calibri,Verdana,Times New Roman;">Junior Office Assistant
</span></font>
<br></font>  

<p>
<br></p>  

<p>
<br></p>  

<p><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">
<br></font></p>
</td>  
<td style="text-align: justify;"><font size="2">&nbsp;</font>
</td>  
<td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mrs. Debaki Darai</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Gardner</font>
<br>
<br>
<br>
<br>
<br></font>
</td>
</tr>  
<tr>  
<td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">Mr. Dambar Bahadur Ghale</font><font size="2">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">Night Guard</font>
<br>
</td>  
<td style="text-align: justify;"><font size="2">&nbsp;</font>
</td>  
<td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">Mr. Birkha Raj Ghale</font><font size="2">
<br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">Night Guard</font>
</td>
</tr></tbody>
</table>

 <!--till here admin and support-->               
                
                
                
                
                
                

<div style="text-align: justify;"><font face="Verdana, Arial, Helvetica, sans-serif"><font style="font-weight: bold; color: rgb(0, 0, 153); font-family: Calibri,Verdana,Times New Roman;">Research Staff</font>
<br />
</font><font size="2"><br style="font-family: Calibri,Verdana,Times New Roman;" />
</font>


<div style="text-align: justify;"><font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">Our social research staff (researchers, research managers, and supervisors) has been trained following research protocols of the Survey Research Center at the University of Michigan, USA, a world leader in survey research.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">The staff is well trained in and has expertise on:</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp; o Interviewing techniques</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp; o Survey instrument designs and data collection</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp; o Ethnographic/qualitative research methods (data
<br />
&nbsp; &nbsp; &nbsp;&nbsp; collection)</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">The staff has been trained by well known researchers from the University of M</font><font style="font-family: Calibri,Verdana,Times New Roman;">ichigan and the University of North Carolina-Chapel Hill in the USA.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">The survey research staff is highly experienced in implementing and managing large scale longitudinal panel surveys.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">The aggressive program of ethnographic and archival data collection has led to a number of methodological innovations such as the Neighborhood History Calendar which collects yearly information about changes in neighborhood institutions and the Systematic Anomalous Case Analysis.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">A majority of the research staff has been continuously working since the inception of PERL and ISER-N.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font color="#006600" face="Verdana, Arial, Helvetica, sans-serif" style="font-weight: bold; font-family: Calibri,Verdana,Times New Roman;">Quality Control</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">Our quality control procedures meet or exceed global survey research standards.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp;&nbsp; - We maintain a high supervisor-to-interviewer ratio.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp;&nbsp; - Completed interviews are checked at least two times
<br />
&nbsp; &nbsp; &nbsp;&nbsp; for errors and </font></font><font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">omissions before data entry.</font></font>
</div>

<table width="468" cellspacing="0" cellpadding="4" border="0" height="736" style="font-family: Verdana,Arial,Helvetica,sans-serif;">
    <tbody>
        
<tr>
            
<td style="text-align: justify; font-family: Calibri,Verdana,Times New Roman;">

<span style="font-size: smaller;"><font style="font-family: Calibri,Verdana,Times New Roman;">Ms. Indra K. Chaudhary</font><img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_9c846ee397cffdde8cd2a8acdd059b17.jpeg" style="width: 83px; height: 90px;" alt="" />
<br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">Study Manager</font>
<br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">M. A. (Sociology on-going)</font>
<br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font>
<br />
            
</span><font size="1"><a href="mailto:%20ichaudhary@isernepal.org.np" target="_blank">

<span style="font-size: smaller;">E-mail
</span></a></font>
</td>
            
<td style="text-align: justify;"><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<br />
            </font>
</td>
            
<td style="font-family: Calibri,Verdana,Times New Roman; text-align: justify;">
            

<div style="text-align: left;">&nbsp;
</div>
            

<div style="text-align: left;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Binoj Kumar Shrestha</font><font size="1"><img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_32726799499d96a086ebc8e182ee149e.jpeg" alt="Binoj Shrestha" style="width: 85px; height: 108px; font-family: Calibri,Verdana,Times New Roman;" /><br style="font-family: Calibri,Verdana,Times New Roman;" />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Research Associate </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">M. Sc. (Env. Science &amp; Botany)</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">
<br />
            <a href="mailto:%20bshrestha@isernepal.org.np" target="_blank" style="font-family: Calibri,Verdana,Times New Roman;">E-mail</a></font><font size="2">
<br />
            
<br />
            
<br />
            </font>
</div>
            
</td>
        
</tr>
        
<tr>
            
<td style="vertical-align: top;"><font size="+0"><font size="2"><a href="mailto:rghimire@isernepal.org.np"><img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_4195982e619f899fc368c611619676dd.jpeg" style="width: 84px; height: 100px;" alt="" /></a></font></font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Rajendra Ghimire</font><font size="1"><br style="font-family: Calibri,Verdana,Times New Roman;" />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Research Supervisor
<br />
            M.A. (Sociology On-going)
<br />
            Tribhuvan University, Nepal
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><a href="mailto:%20rghimire@isernepal.org.np" target="_blank">E-mail</a></font>
</td>
            
<td style="vertical-align: top;">&nbsp;
</td>
            
<td style="vertical-align: top;">&nbsp;
</td>
        
</tr>
        
<tr>
            
<td style="text-align: justify;">
            

<p>&nbsp;</p>
            <font size="2"><img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_90fefc5d28976da92dfa98aedeb8ab1a.jpeg" alt="" style="width: 84px; height: 99px;" /></font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Prem Prakash Pandit</font><font size="1">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Research Supervisor</font><font size="1">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">M. Ed. (Health)</font><font size="1">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font><font size="1">
<br />
            <font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><a href="mailto:%20%20ppandit@isernepal.org.np" target="_blank">E-mail</a></font></font><font size="2">
<br />
            
<br />
            </font>
</td>
            
<td style="text-align: justify;"><font size="2">&nbsp;</font>
</td>
            
<td style="text-align: justify; font-family: Calibri,Verdana,Times New Roman;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">
<br />
            Mr. Krishna Lama</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_c981e01def62d14d43a30fb1ea23bbbd.jpeg" alt="" style="width: 91px; height: 114px;" /></font><font size="1">
<br />
            </font><font size="1"><font style="font-family: Calibri,Verdana,Times New Roman;">Research Supervisor</font>
<br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">M. A. (Sociology on-going)</font>
<br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font>
<br />
            <a href="mailto:%20klama@isernepal.org.np" target="_blank">E-mail</a></font>
</td>
        
</tr>
        
<tr>
            
<td style="text-align: justify;">
            

<p><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">
<br />
            </font></p>
            

<p><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Krishna Shrestha</font><font size="1">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Asst. Research Officer</font><font size="1">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">I. A. (Economics)</font><font size="1">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font></p>
            

<p><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">
<br />
            </font></p>
            
</td>
            
<td style="text-align: justify;"><font size="2">&nbsp;</font>
</td>
            
<td style="text-align: justify;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">
<br />
            Mr. Dil Bahadur C.K.</font><font size="1"><img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_1ced9fa309fdb007049f332723d0ece4.jpeg" alt="" style="width: 89px; height: 103px;" />
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Asst. Research Officer</font><font size="1">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">I. A. (English and Math)</font><font size="1">, </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font>
</td>
        
</tr>
        
<tr>
            
<td style="text-align: justify;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Ms. Adina Gurung</font><font size="1"><img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_072790858548ee214c907331fe841f25.jpeg" alt="Adina Gurung" style="width: 77px; height: 95px;" />
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Asst. Research Officer
<br />
            M.A. (Sociology On-going)
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepa</font><font size="1">l
<br />
            
<br />
            </font>
</td>
            
<td style="text-align: justify;"><font size="2">&nbsp;</font>
</td>
            
<td style="text-align: justify;">
    </td>
        
</tr>
        
<tr>
            
<td style="vertical-align: top;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Ms. Nira Gurung</font><font size="1"><img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_68cff057a37fd0c0f5a39fb346bf891e.jpeg" alt="" style="width: 90px; height: 96px;" />
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Team Leader</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">+2 (</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Health on-going)
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font>
</td>
            
<td style="vertical-align: top;">&nbsp;
</td>
            
<td style="vertical-align: top;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Ms. Harka Maya Gurung<img border="0" align="right" src="http://www.isernepal.org.np/admin/pg/PG_bed7619125aa77c6849345c48d3bf863.jpeg" alt="Harka   Maya" style="width: 87px; height: 103px;" /></font><font size="1">
<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Team Leader
<br />
            I.A. (Nepali)
<br />
            Tribhuvan University Nepal</font>
</td>
        
</tr>
    </tbody>

</table>
<font size="2"><br style="font-family: Verdana,Arial,Helvetica,sans-serif;" />
</font>


<div style="text-align: center;"><font size="2" style="font-family: Calibri,Verdana,Times New Roman; font-weight: bold;"><font size="2" style="font-family: Verdana,Arial,Helvetica,sans-serif;"><a href="../?mode=1&amp;topic=54" target="_self">Interviewers</a></font></font>
</div>
<font size="2" style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font>
</div>





<!-- origial -->

<p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;"><b><span style="color: rgb(0, 32, 96); font-family: 'Calibri','sans-serif';"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Administrative and Support Staff</font></span></b></p>  <p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;">&nbsp;</p>  <p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;"><font face="Calibri, Verdana, Times New Roman" size="2"><span style="font-family: Calibri,Verdana,Times New Roman;">The administrative and financial management unit is headed by an&nbsp;Executive Officer (Masters in Business Administration) who has a significant experience in both administrative as well as&nbsp;financial management. He is supported by an Accounts Officer and a Logistics Assistant and several support staff. </span><br></font></p>  <p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;"><br></p>  <p class="MsoNormal" style="margin: 0in 0in 0pt; text-align: justify;">&nbsp;</p>  <table style="width: 642px; font-family: Verdana,Arial,Helvetica,sans-serif; height: 283px;" border="0" cellpadding="4" cellspacing="0">  <tbody>  <tr></tr>  <tr>  <td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Krishna Ji Ghimire</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><img style="width: 99px; height: 121px;" alt="" src="http://www.isernepal.org.np/admin/pg/PG_a85e0dfd50d74fa1fb16379bfd80a0c0.jpeg" align="right" border="0"></font><font size="1"><br style="font-family: Calibri,Verdana,Times New Roman;"></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Executive Officer</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">MBA&nbsp; </font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Tribhuvan University, Nepal</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br><a href="mailto:%20kghimire@isernepal.org.np" target="_blank">E-mail </a></font><font size="2"><br></font><font size="2"><br><br><br></font></td>  <td style="text-align: justify;"><br></td>  <td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Ms. Gita Subedi</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><img style="width: 90px; height: 117px;" alt="Gita Subedi" src="http://www.isernepal.org.np/admin/pg/PG_6c7468bd003803208bc9e8bdb41a8469.jpeg" align="right" border="0"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Account Officer</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">M.A. (Sociology On-going)&nbsp; </font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Tribhuvan University, Nepal</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br><a href="mailto:%20gsubedi@isernepal.org.np" target="_blank">E-mail</a></font><font size="2"><br><br><br></font></td></tr>  <tr>  <td style="text-align: justify;"><font size="2"><img style="width: 100px; height: 123px;" alt="Bamdev Adhikari" src="http://www.isernepal.org.np/admin/pg/PG_9f94fd3cf602796763cf59d164a30c28.jpeg" align="right" border="0"></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Bamdev Adhikari</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Logistic Assistant</font><font size="2"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><br></font></td>  <td style="text-align: justify;"><font size="2">&nbsp;</font></td>  <td style="text-align: justify;"><font size="2"><img style="width: 90px; height: 112px;" alt="Rishi Neupane" src="http://www.isernepal.org.np/admin/pg/PG_6e8d1e700318e528b3de3c956e2a43af.jpeg" align="right" border="0"></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Rishi Neupane</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><font size="1"><span style="font-family: Calibri,Verdana,Times New Roman;">Senior Office Assistant</span></font><br><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><br></font></td></tr>  <tr>  <td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><br></font><font size="2"><img style="width: 90px; height: 104px;" alt="Bimal Darai" src="http://www.isernepal.org.np/admin/pg/PG_7c0b8109f24643864fd67ff7e95f9bab.jpeg" align="right" border="0"></font><br><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mr. Bimal Darai</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><font size="1"><span style="font-family: Calibri,Verdana,Times New Roman;">Junior Office Assistant</span></font><br></font>  <p><br></p>  <p><br></p>  <p><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><br></font></p></td>  <td style="text-align: justify;"><font size="2">&nbsp;</font></td>  <td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Mrs. Debaki Darai</font><font style="font-family: Calibri,Verdana,Times New Roman;" size="1"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2"><font style="font-family: Calibri,Verdana,Times New Roman;" size="1">Gardner</font><br><br><br><br><br></font></td></tr>  <tr>  <td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">Mr. Dambar Bahadur Ghale</font><font size="2"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">Night Guard</font><br></td>  <td style="text-align: justify;"><font size="2">&nbsp;</font></td>  <td style="text-align: justify;"><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">Mr. Birkha Raj Ghale</font><font size="2"><br></font><font style="font-family: Calibri,Verdana,Times New Roman;" size="2">Night Guard</font></td></tr></tbody></table>


<!-- original research-->
<div style="text-align: justify;"><font face="Verdana, Arial, Helvetica, sans-serif"><font style="font-weight: bold; color: rgb(0, 0, 153); font-family: Calibri,Verdana,Times New Roman;">Research Staff</font><br />
</font><font size="2"><br style="font-family: Calibri,Verdana,Times New Roman;" />
</font>
<div style="text-align: justify;"><font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">Our social research staff (researchers, research managers, and supervisors) has been trained following research protocols of the Survey Research Center at the University of Michigan, USA, a world leader in survey research.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">The staff is well trained in and has expertise on:</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp; o Interviewing techniques</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp; o Survey instrument designs and data collection</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp; o Ethnographic/qualitative research methods (data<br />
&nbsp; &nbsp; &nbsp;&nbsp; collection)</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">The staff has been trained by well known researchers from the University of M</font><font style="font-family: Calibri,Verdana,Times New Roman;">ichigan and the University of North Carolina-Chapel Hill in the USA.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">The survey research staff is highly experienced in implementing and managing large scale longitudinal panel surveys.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">The aggressive program of ethnographic and archival data collection has led to a number of methodological innovations such as the Neighborhood History Calendar which collects yearly information about changes in neighborhood institutions and the Systematic Anomalous Case Analysis.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">A majority of the research staff has been continuously working since the inception of PERL and ISER-N.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font face="Verdana, Arial, Helvetica, sans-serif" color="#006600" style="font-weight: bold; font-family: Calibri,Verdana,Times New Roman;">Quality Control</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">Our quality control procedures meet or exceed global survey research standards.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp;&nbsp; - We maintain a high supervisor-to-interviewer ratio.</font></font><br style="font-family: Calibri,Verdana,Times New Roman;" />
<font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp;&nbsp; - Completed interviews are checked at least two times<br />
&nbsp; &nbsp; &nbsp;&nbsp; for errors and </font></font><font size="2"><font style="font-family: Calibri,Verdana,Times New Roman;">omissions before data entry.</font></font></div>
<table width="468" height="736" cellspacing="0" cellpadding="4" border="0" style="font-family: Verdana,Arial,Helvetica,sans-serif;">
    <tbody>
        <tr>
            <td style="text-align: justify; font-family: Calibri,Verdana,Times New Roman;"><span style="font-size: smaller;"><font style="font-family: Calibri,Verdana,Times New Roman;">Ms. Indra K. Chaudhary</font><img border="0" align="right" alt="" style="width: 83px; height: 90px;" src="http://www.isernepal.org.np/admin/pg/PG_9c846ee397cffdde8cd2a8acdd059b17.jpeg" /><br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">Study Manager</font><br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">M. A. (Sociology on-going)</font><br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font><br />
            </span><font size="1"><a target="_blank" href="mailto:%20ichaudhary@isernepal.org.np"><span style="font-size: smaller;">E-mail</span></a></font></td>
            <td style="text-align: justify;"><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />
            </font></td>
            <td style="font-family: Calibri,Verdana,Times New Roman; text-align: justify;">
            <div style="text-align: left;">&nbsp;</div>
            <div style="text-align: left;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Binoj Kumar Shrestha</font><font size="1"><img border="0" align="right" style="width: 85px; height: 108px; font-family: Calibri,Verdana,Times New Roman;" alt="Binoj Shrestha" src="http://www.isernepal.org.np/admin/pg/PG_32726799499d96a086ebc8e182ee149e.jpeg" /><br style="font-family: Calibri,Verdana,Times New Roman;" />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Research Associate </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">M. Sc. (Env. Science &amp; Botany)</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><br />
            <a style="font-family: Calibri,Verdana,Times New Roman;" target="_blank" href="mailto:%20bshrestha@isernepal.org.np">E-mail</a></font><font size="2"><br />
            <br />
            <br />
            </font></div>
            </td>
        </tr>
        <tr>
            <td style="vertical-align: top;"><font size="+0"><font size="2"><a href="mailto:rghimire@isernepal.org.np"><img border="0" align="right" alt="" style="width: 84px; height: 100px;" src="http://www.isernepal.org.np/admin/pg/PG_4195982e619f899fc368c611619676dd.jpeg" /></a></font></font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Rajendra Ghimire</font><font size="1"><br style="font-family: Calibri,Verdana,Times New Roman;" />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Research Supervisor<br />
            M.A. (Sociology On-going)<br />
            Tribhuvan University, Nepal<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><a target="_blank" href="mailto:%20rghimire@isernepal.org.np">E-mail</a></font></td>
            <td style="vertical-align: top;">&nbsp;</td>
            <td style="vertical-align: top;">&nbsp;</td>
        </tr>
        <tr>
            <td style="text-align: justify;">
            <p>&nbsp;</p>
            <font size="2"><img border="0" align="right" style="width: 84px; height: 99px;" alt="" src="http://www.isernepal.org.np/admin/pg/PG_90fefc5d28976da92dfa98aedeb8ab1a.jpeg" /></font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Prem Prakash Pandit</font><font size="1"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Research Supervisor</font><font size="1"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">M. Ed. (Health)</font><font size="1"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font><font size="1"><br />
            <font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><a target="_blank" href="mailto:%20%20ppandit@isernepal.org.np">E-mail</a></font></font><font size="2"><br />
            <br />
            </font></td>
            <td style="text-align: justify;"><font size="2">&nbsp;</font></td>
            <td style="text-align: justify; font-family: Calibri,Verdana,Times New Roman;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><br />
            Mr. Krishna Lama</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><img border="0" align="right" style="width: 91px; height: 114px;" alt="" src="http://www.isernepal.org.np/admin/pg/PG_c981e01def62d14d43a30fb1ea23bbbd.jpeg" /></font><font size="1"><br />
            </font><font size="1"><font style="font-family: Calibri,Verdana,Times New Roman;">Research Supervisor</font><br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">M. A. (Sociology on-going)</font><br />
            <font style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font><br />
            <a target="_blank" href="mailto:%20klama@isernepal.org.np">E-mail</a></font></td>
        </tr>
        <tr>
            <td style="text-align: justify;">
            <p><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><br />
            </font></p>
            <p><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Krishna Shrestha</font><font size="1"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Asst. Research Officer</font><font size="1"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">I. A. (Economics)</font><font size="1"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font></p>
            <p><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><br />
            </font></p>
            </td>
            <td style="text-align: justify;"><font size="2">&nbsp;</font></td>
            <td style="text-align: justify;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><br />
            Mr. Dil Bahadur C.K.</font><font size="1"><img border="0" align="right" style="width: 89px; height: 103px;" alt="" src="http://www.isernepal.org.np/admin/pg/PG_1ced9fa309fdb007049f332723d0ece4.jpeg" /><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Asst. Research Officer</font><font size="1"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">I. A. (English and Math)</font><font size="1">, </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font></td>
        </tr>
        <tr>
            <td style="text-align: justify;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Ms. Adina Gurung</font><font size="1"><img border="0" align="right" style="width: 77px; height: 95px;" alt="Adina Gurung" src="http://www.isernepal.org.np/admin/pg/PG_072790858548ee214c907331fe841f25.jpeg" /><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Asst. Research Officer<br />
            M.A. (Sociology On-going)<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepa</font><font size="1">l<br />
            <br />
            </font></td>
            <td style="text-align: justify;"><font size="2">&nbsp;</font></td>
            <td style="text-align: justify;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Mr. Mangal Raj Darai</font><font size="1"><img border="0" align="right" style="width: 89px; height: 106px;" alt="Mangal" src="http://www.isernepal.org.np/admin/pg/PG_cd4c83df82671cd221806d5b1e003d71.jpeg" /><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Asst. Research Officer<br />
            I.A. (</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Population on-going)<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font></td>
        </tr>
        <tr>
            <td style="vertical-align: top;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Ms. Nira Gurung</font><font size="1"><img border="0" align="right" style="width: 90px; height: 96px;" alt="" src="http://www.isernepal.org.np/admin/pg/PG_68cff057a37fd0c0f5a39fb346bf891e.jpeg" /><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Team Leader</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">+2 (</font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Health on-going)<br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Tribhuvan University, Nepal</font></td>
            <td style="vertical-align: top;">&nbsp;</td>
            <td style="vertical-align: top;"><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Ms. Harka Maya Gurung<img border="0" align="right" style="width: 87px; height: 103px;" alt="Harka   Maya" src="http://www.isernepal.org.np/admin/pg/PG_bed7619125aa77c6849345c48d3bf863.jpeg" /></font><font size="1"><br />
            </font><font size="1" style="font-family: Calibri,Verdana,Times New Roman;">Team Leader<br />
            I.A. (Nepali)<br />
            Tribhuvan University Nepal</font></td>
        </tr>
    </tbody>
</table>
<font size="2"><br style="font-family: Verdana,Arial,Helvetica,sans-serif;" />
</font>
<div style="text-align: center;"><font size="2" style="font-family: Calibri,Verdana,Times New Roman; font-weight: bold;"><font size="2" style="font-family: Verdana,Arial,Helvetica,sans-serif;"><a target="_self" href="../?mode=1&amp;topic=54">Interviewers</a></font></font></div>
<font size="2" style="font-family: Calibri,Verdana,Times New Roman;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></div>