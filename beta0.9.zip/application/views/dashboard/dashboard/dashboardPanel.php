<style>.switch-right-grid{margin-bottom: 20px;}.lnr{font-size: 30px;}.switch-right-grid1{padding: 2em;text-align: center;}</style>
			<div id="page-wrapper">
				<div class="graphs">

		<div class="switches">
			
				<div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
							<i class="lnr lnr-file-empty"></i>
							<h3>Ledger Create</h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
							<i class="lnr lnr-file-empty"></i>
							<h3>Ledger Listing</h3>
						</div>
					</div>
					
				</div>
				<div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
							<i class="lnr lnr-file-empty"></i>
							<h3>Journal Entry</h3>
						</div>
					</div>
					
				</div>
                            
                            <div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
							<i class="lnr lnr-file-empty"></i>
							<h3>Transactions Listing</h3>
						</div>
					</div>
					
				</div>
                            
                            <div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
							<i class="lnr lnr-file-empty"></i>
							<h3>Day Book</h3>
						</div>
					</div>
					
				</div>
                            
                            <div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
                                                    <i class="lnr lnr-file-empty"></i>
							<h3>User Manual</h3>
						</div>
					</div>
					
				</div>
                    
                    <div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
                                                    <i class="lnr lnr-file-empty"></i>
							<h3>User Manual</h3>
						</div>
					</div>
					
				</div>
                    
                    <div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
                                                    <i class="lnr lnr-file-empty"></i>
							<h3>User Manual</h3>
						</div>
					</div>
					
				</div>
                    
                    <div class="col-md-4 switch-right">
					<div class="switch-right-grid">
						<div class="switch-right-grid1">
                                                    <i class="lnr lnr-file-empty"></i>
							<h3>User Manual</h3>
						</div>
					</div>
					
				</div>
				<div class="clearfix"></div>
			</div>
		</div>

				
			<!--body wrapper start-->
			</div>
			 <!--body wrapper end-->
		</div>