<!DOCTYPE HTML>
<html>
<head>
	<title>Account :: Home </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="design" />

	<link href="<?php echo base_url().'contents/css/style.css'; ?>" rel='stylesheet' type='text/css' />
	<link href="<?php echo base_url().'contents/css/preview.css'; ?>" rel='stylesheet' type='text/css' />
	
<link href='//fonts.googleapis.com/css?family=Cabin:400,400italic,500,500italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>

<Style>
main {
  margin: 0px;
  padding: 0px;
}
main div {
  padding: 10px;
  margin: 0px;
}
main div h5, main div h4{
    margin: 0px;
}
.inline-block-center {
  text-align: center;
}
.inline-block-center div {
  display: inline-block;
  text-align: left;
}
.flex-center {
  display: flex;
  justify-content: center;
}
.form-errors 
                {
                    font-size: 14px;
                    padding: 10px;
                    color:red;
                }
                .form_errors 
                {
                    font-size: 14px;
                    padding: 10px;
                    color:red;
                }
                
.btns-primary {
    background-color: #00aced !important;
    border-color: #00aced !important;
    color: #fff;
    padding: 6px 10px;
}
</style>

</head>

<body class="sticky-header left-side-collapsed">
	<section>
