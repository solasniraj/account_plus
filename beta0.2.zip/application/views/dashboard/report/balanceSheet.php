<div id="page-wrapper">
	<div class="graphs">
		<br>
		<h3 class="blank1">Bajet hisab</h3>

		<div class="xs tabls">
			<?php  $flashMessage=$this->session->flashdata('flashMessage'); 
			if(!empty($flashMessage))
				{  ?>
			<div class="alert alert-success fade in">
				<p style="text-align:center;font-size:18px;"><strong>!!&nbsp;<?php echo $flashMessage; ?> </strong></p>
			</div>
			<hr>
			<?php }
			?>

			<style>

				.table td, .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
					padding: 10px !important;

				}


				.width120 {
					width:120px;
				}


			</style>
			<div data-example-id="simple-responsive-table" class="bs-example4">
				<p class="text-center">january 2015-4-5</p>
				<div class="table-responsive">
					<table class="table table-bordered table-condensed table-stripped">
						<thead>
							<tr>

								<th colspan="4" style="width:280px;">bajet rakam number</th>
								<th>21111</th>
								<th>21113</th>
								<th>2212</th>
								<th>2113</th>


							</tr>

							<tr>

								<th colspan="4" style="width:280px;">bajet rakam </th>
								<th>salary</th>
								<th>mahangi bhatta</th>
								<th>sanchalan sammvar karcha</th>
								<th>office karcha</th>

							</tr>
							

						</thead>
						<tbody>

							<tr>

								<td colspan="3" style="width:280px;">&nbsp;</td>
								<td>nepal sarkar</td>
								<td colspan="4">&nbsp;</td>


							</tr>


							<tr>

								<td colspan="3" style="width:280px;">barsik baget </td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>

							


							</tr>


							<tr>

								<td colspan="3" style="width:280px;">yo mahinako nikasa </td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>

							


							</tr>
							<tr >

								<td >miti </td>
								<td>ga va no</td>
								<td colspan="2">descrption</td>
								<td colspan="4">&nbsp;</td>
								

							


							</tr>

							<tr>

								<td >2015/05/2</td>
								<td>2</td>
								<td colspan="2">malsaman karib bikri</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
							
					
								

							


							</tr>

							<tr>

								<td >2015/05/2</td>
								<td>2</td>
								<td colspan="2">malsaman karib bikri</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
		
					
								

							


							</tr>
							<tr>

								<td >2015/05/2</td>
								<td>2</td>
								<td colspan="2">malsaman karib bikri</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
					
					
								

							


							</tr>


							<tr>

								<td colspan="4" style="width:280px;">yo mahinako jamma </td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
							

							</tr>td

							<tr>

								<td colspan="4" style="width:280px;">aaglo mahinako karcha </td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
						


							</tr>
							<tr>

								<td colspan="4" style="width:280px;">yo mahilnako karcha </td>					
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
								<td>100000</td>
						
							

							</tr>



						</tbody>
					</table>
				</div><!-- /.table-responsive -->
			</div>
		</div>
	</div>
</div>
</div>
