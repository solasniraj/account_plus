<!DOCTYPE HTML>
<html>
<head>
	<title>Account :: Home </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="design" />

	<link href="<?php echo base_url().'contents/css/style.css'; ?>" rel='stylesheet' type='text/css' />
	<link href="<?php echo base_url().'contents/css/preview.css'; ?>" rel='stylesheet' type='text/css' />
	
<link href='//fonts.googleapis.com/css?family=Cabin:400,400italic,500,500italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>


</head>

<body class="sticky-header left-side-collapsed">
	<section>
