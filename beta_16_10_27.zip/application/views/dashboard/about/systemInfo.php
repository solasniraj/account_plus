            <div id="page-wrapper">
                <div class="graphs">
                    <h3 class="blank1">System Details</h3>
                     
                    <div class="tab-content">
                        <h2>Account Plus</h2>
                        <p>A complete accounting package for your office.</p>
                        <strong></strong>
                </div>
            
        </div>
    </div>
