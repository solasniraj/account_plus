<div id="page-wrapper">
	<div class="graphs">
		<br>
		<h3 class="blank1">Bank Cash Book</h3>

		<div class="xs tabls">
			<?php  $flashMessage=$this->session->flashdata('flashMessage'); 
			if(!empty($flashMessage))
				{  ?>
					<div class="alert alert-success fade in">
						<p style="text-align:center;font-size:18px;"><strong>!!&nbsp;<?php echo $flashMessage; ?> </strong></p>
					</div>
					<hr>
					<?php }
					?>

					<style>

						.table td, .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
							padding: 10px !important;

						}

						.table td, .table th{
							border: 1px solid black;
						}


						.table{
							border-color:1px solid black;
						}


						.width120 {
							width:120px;
						}
						.text-left {border-top-style: groove;}


					</style>
					<div data-example-id="simple-responsive-table" class="bs-example4">
						<h3 class="text-center"><span class="label label-default"> January 2015-4-5</h3></span>
						

						<div class="table-responsive">
							<table class="table">
								<tbody>

									<tr class="text-left">

										<th rowspan="2" style="padding-bottom:15px;">Date</th>
										<th rowspan="2" style="padding-bottom:15px;">sanket no</th>
										<th rowspan="2" style="padding-bottom:15px;" class="width120">description</th>
										<th colspan="2">Cash mooujad</th>
										<th colspan="4">Bank mooujad</th>
										<th colspan="2">Bajet karcha</th>
										<th  colspan="2">Running year peski</th>
										<th  colspan="2">Previous year peski</th>
										<th  colspan="2">Others</th>
										<th  rowspan="2">Remark</th>

									</tr>

									<tr>
										<th>Debit</th>
										<th>Credit</th>
										<th>fasdf</th>
										<th>Debit</th>
										<th>Credit</th>
										<th>Check No</th>
										<th>Baki</th>
										<th>Rakam</th>
										<th>Rs</th>
										<th>Diyeyeko</th>
										<th>Farciyeko</th>
										<th>Jimaryai sateko</th>
										<th>Debit</th>
										<th>Credit</th>


									</tr>


									<tr>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>

									</tr>

									<tr>
										<td>1</td>
										<td>1</td>
										<th>bank alliya</th>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>

									</tr>



									<tr>
										<td>1</td>
										<td>1</td>
										<th>rakam aamandi badhiyeko</th>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>

									</tr>
									

									<tr>
										<td>1</td>
										<td>1</td>
										<th>malsaman karid bhuktani</th>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
									</tr>


									<tr>
										<td>1</td>
										<td>1</td>
										<th>marmat rakam bhuktani</th>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>

									</tr>

									<tr>
										<th colspan="3"> yo mahinako jamma</th>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
									</tr>


									<tr>
										<th colspan="3"> Gata mahinako jamma</th>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
									</tr>


									<tr>
										<th colspan="3"> Hal sammako jamma</th>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>

									</tr>



								</tbody>	
							</table>

						</div><!-- /.table-responsive -->
					</div>
				</div>
			</div>
		</div>
	</div>
