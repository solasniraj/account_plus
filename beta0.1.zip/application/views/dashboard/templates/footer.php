
    

        <!--footer section start-->
			<footer>
			   <p>&copy salyani. All Rights Reserved.</p>
			</footer>
        <!--footer section end-->

      <!-- main content end-->
   </section>
  
<script src="<?php echo base_url().'contents/js/jquery.nicescroll.js'; ?>"></script>
<script src="<?php echo base_url().'contents/js/scripts.js'; ?>"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="<?php echo base_url().'contents/js/bootstrap.min.js'; ?>"></script>
</body>
</html>