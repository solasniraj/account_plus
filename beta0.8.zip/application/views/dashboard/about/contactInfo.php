            <div id="page-wrapper">
                <div class="graphs">
                    <h3 class="blank1">Contact Details</h3>
                     
                    <div class="tab-content">
                        <h2>Salyani Technologies Pvt. Ltd.</h2>
                        <h4>Lions Chowk, Narayangarh, Chitwan, Nepal</h4>
                        <strong>Contact : 056-533977, &nbsp;&nbsp;&nbsp;+977-9801533977</strong>
                </div>
            
        </div>
    </div>
