            <div id="page-wrapper">
                <div class="graphs">
                    <h3 class="blank1">User Manual</h3>
                     
                    <div class="tab-content">
                        <h2 style="display: inline-block;">Account Plus</h2>&nbsp;&nbsp;&nbsp;<p style="display: inline-block;">A complete accounting package for your office.</p>
                        <h3>User Manual</h3>
                        <strong></strong>
                </div>
            
        </div>
    </div>
