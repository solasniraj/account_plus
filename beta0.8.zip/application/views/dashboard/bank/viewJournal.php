                                    <div class="table-responsive">
                                        <table class="tablee">
                                            <tbody>

                                                <tr>
                                                 <td class="col-md-1"><b>Journal no</b></td>
                                                    <td class="col-md-1"><b>Journal type</b></td>
                                                    <td class="col-md-1"><b>Date</b></td>
                                                    <td class="col-md-1">Bank Balance</td>
                                                    </tr>


                                                    <tr>
                                                    <td id="journalNo">
                                                            <input type="text" id="journal" class="form-control" >
                                                        </td>
                                                       <td><select class="form-control" id="programsList" onchange="whenProgramIsSelected(this)">
                                                  <option value="">Select Types</option>
                                                         </select></td>    
                                                        
                                        <td><input class="form-control" id="datepicker" type="text" placeholder="Day/Month/Year"></td>
                                                        <td id="journalNo">
                                                            <input type="text" id="journal" class="form-control" >
                                                        </td>

                                                        
                                                    </tr>
                                                    </tbody>
                                                    </table>
                                                    </div>


                                                    <br>

                                                    <div class="tab-content">
<table class="table table-striped table-bordered table-condensed">
<thead>
<tr>
<th>Code#</th>
<th>A/C Head </th>
<th>Sub-ledger</th>
<th>Donar-list</th>
<th>Ledger type</th>
<th>Description</th>
<th>Debit</th>
<th>Credit</th>
<th>Cheque Number</th>
</tr>
</thead>
</table>
</div>




