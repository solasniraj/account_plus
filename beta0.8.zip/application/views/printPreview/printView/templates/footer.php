
    

        

     
   </section>
  
<script src="<?php echo base_url().'contents/js/jquery.nicescroll.js'; ?>"></script>
<script src="<?php echo base_url().'contents/js/scripts.js'; ?>"></script>

</body>
</html>