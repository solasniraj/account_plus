<div id="page-wrapper">
	<div class="graphs">
		<br>
		<h3 class="blank1">Bank Cash Book</h3>

		<div class="xs tabls">
			<?php  $flashMessage=$this->session->flashdata('flashMessage'); 
			if(!empty($flashMessage))
				{  ?>
			<div class="alert alert-success fade in">
				<p style="text-align:center;font-size:18px;"><strong>!!&nbsp;<?php echo $flashMessage; ?> </strong></p>
			</div>
			<hr>
			<?php }
			?>

			<style>

				.table td, .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
					padding: 10px !important;

				}


				.width120 {
					width:120px;
				}


			</style>
			<div data-example-id="simple-responsive-table" class="bs-example4">
				<p class="text-center">january 2015-4-5</p>
				<div class="table-responsive">
					<table class="table table-bordered table-condensed table-stripped">
						<thead>
							<tr>

								<th rowspan="2" style="padding-bottom:15px;">Date</th>
								<th rowspan="2" style="padding-bottom:15px;">sanket no</th>
								<th rowspan="2" style="padding-bottom:15px;" class="width120">description</th>
								<th colspan="2">cash mooujad</th>
								<th colspan="4">bank mooujad</th>
								<th colspan="2">bajet karcha</th>
								<th  colspan="2">running year peski</th>
								<th  colspan="2">previous year peski</th>
								<th  colspan="2">others</th>
								<th  rowspan="2">remarak</th>

							</tr>
							<tr>
								<th>debit</th>
								<th>credit</tth>
									<th>fasdf</th>
									<th>debit</th>
									<th>credit</td>
										<th>check no</th>
										<th>baki</th>
										<th>rakam</th>
										<th>Rs</th>
										<th>diyeyeko</th>
										<th>farciyeko</th>
										<th>jimaryai sateko</th>
										<th>debit</th>
										<th>credit</th>


									</tr>

								</thead>
								<tbody>
									<tr>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>

									</tr>

									<tr>
										<td>1</td>
										<td>1</td>
										<td>bank alliya</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>
										<td>1</td>

									</tr>

								</tr>

								<tr>
									<td>1</td>
									<td>1</td>
									<td>rakam aamandi badhiyeko</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>
									<td>1</td>

								</tr>
							</tr>

							<tr>
								<td>1</td>
								<td>1</td>
								<td>malsaman karid bhuktani</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>
								<td>1</td>

							</tr>
						</tr>

						<tr>
							<td>1</td>
							<td>1</td>
							<td>marmat rakam bhuktani</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>

						</tr>

						<tr>
							<td colspan="3"> yo mahinako jamma</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>


						</tr>

						<tr>
							<td colspan="3"> gata mahinako jamma</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>


						</tr>

						<tr>
							<td colspan="3"> hal sammako jamma</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>
							<td>1</td>

						</tr>






					</tbody>
				</table>
			</div><!-- /.table-responsive -->
		</div>
	</div>
</div>
</div>
</div>
