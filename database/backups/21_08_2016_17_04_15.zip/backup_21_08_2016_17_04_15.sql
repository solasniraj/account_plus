#
# TABLE STRUCTURE FOR: user_info
#

DROP TABLE IF EXISTS `user_info`;

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `user_info` (`id`, `user_name`, `password`, `status`, `user_type`) VALUES ('1', 'bhomnath', '9fe3ef0f7bab8b8f9c60056e680cd727', '1', 'administrator');
INSERT INTO `user_info` (`id`, `user_name`, `password`, `status`, `user_type`) VALUES ('2', 'sanoj', '9c5ddd54107734f7d18335a5245c286b', '1', 'administrator');
INSERT INTO `user_info` (`id`, `user_name`, `password`, `status`, `user_type`) VALUES ('3', 'sanoj', '9c5ddd54107734f7d18335a5245c286b', NULL, NULL);


#
# TABLE STRUCTURE FOR: user_programs_list
#

DROP TABLE IF EXISTS `user_programs_list`;

CREATE TABLE `user_programs_list` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `programName` varchar(255) NOT NULL,
  `programBudget` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `user_programs_list` (`id`, `code`, `programName`, `programBudget`, `category`, `user_id`) VALUES ('1', '2nr5g6', 'fasdfadasdas', 'dfasfadfas', 'afafdadfa', '2');
INSERT INTO `user_programs_list` (`id`, `code`, `programName`, `programBudget`, `category`, `user_id`) VALUES ('2', 'gindagi', 'dopalki', 'intagaj', 'kyakag', '2');
INSERT INTO `user_programs_list` (`id`, `code`, `programName`, `programBudget`, `category`, `user_id`) VALUES ('3', 'timro', 'name', 'k', 'ho', '2');
INSERT INTO `user_programs_list` (`id`, `code`, `programName`, `programBudget`, `category`, `user_id`) VALUES ('4', 'fdfasfd', 'dfasdf', 'fasdf', 'fdasdf', '2');
INSERT INTO `user_programs_list` (`id`, `code`, `programName`, `programBudget`, `category`, `user_id`) VALUES ('5', 'aaa', 'aaa', 'aaa', 'aaa', '1');
INSERT INTO `user_programs_list` (`id`, `code`, `programName`, `programBudget`, `category`, `user_id`) VALUES ('6', 'sdjfbsdjjk`', 'dskjhfkshdjhjhsdf', 'kjhsdkjhfksd hdskhfkjshdjk', 'jkshjkfds hfsdkjhfjksdf', '1');


